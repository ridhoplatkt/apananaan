package com.example

import com.example.data.api.CobaltApiService
import org.junit.Assert.assertEquals
import org.junit.Test

class SnapGrabPlatformDetectionTest {

    private val apiService = CobaltApiService()

    @Test
    fun testPlatformDetection() {
        assertEquals("Instagram", apiService.detectPlatform("https://www.instagram.com/reel/C3x9L8pvyZ1/"))
        assertEquals("YouTube", apiService.detectPlatform("https://youtu.be/dQw4w9WgXcQ"))
        assertEquals("YouTube", apiService.detectPlatform("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("TikTok", apiService.detectPlatform("https://www.tiktok.com/@creator/video/7289123456789"))
        assertEquals("Twitter", apiService.detectPlatform("https://x.com/techfeed/status/1762145890123"))
        assertEquals("Twitter", apiService.detectPlatform("https://twitter.com/news/status/1762145890123"))
        assertEquals("Facebook", apiService.detectPlatform("https://fb.watch/qR7b2NkP/"))
        assertEquals("Pinterest", apiService.detectPlatform("https://pin.it/3xYz8kL"))
        assertEquals("Spotify", apiService.detectPlatform("https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT"))
        assertEquals("Unknown", apiService.detectPlatform("https://randomsite.org/file.mp4"))
    }
}
