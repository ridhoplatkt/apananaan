package com.example.data.model

data class VideoInfo(
    val title: String,
    val author: String = "",
    val thumbnail: String,
    val downloadUrl: String,
    val platform: String,
    val duration: Long = 0L,
    val quality: String = "720p",
    val isAudioOnly: Boolean = false,
    val fileSizeEstimate: Long = 0L,
    val availableQualities: List<String> = listOf("1080p", "720p", "480p", "360p", "MP3 Audio"),
    val originalUrl: String = ""
)
