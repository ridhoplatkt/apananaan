package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SnapGrabDarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    onPrimary = Color.White,
    primaryContainer = DeepViolet,
    onPrimaryContainer = Color.White,
    secondary = ElectricBlue,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF0E3A4A),
    onSecondaryContainer = CyanGlow,
    tertiary = NeonIndigo,
    onTertiary = Color.White,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderHighlight
)

@Composable
fun SnapGrabTheme(
    darkTheme: Boolean = true, // Default to dark mode gradient theme requested
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SnapGrabDarkColorScheme,
        typography = Typography,
        content = content
    )
}
