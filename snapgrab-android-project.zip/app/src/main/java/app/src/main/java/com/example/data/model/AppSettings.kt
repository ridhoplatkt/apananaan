package com.example.data.model

data class AppSettings(
    val defaultQuality: String = "720p",
    val wifiOnly: Boolean = false,
    val downloadFolder: String = "Downloads/SnapGrab",
    val themeStyle: String = "Purple Blue Gradient",
    val autoPlayOnDownload: Boolean = false
)
