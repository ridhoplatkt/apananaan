package com.example.data.model

enum class DownloadStatus {
    PENDING,
    DOWNLOADING,
    COMPLETED,
    FAILED,
    PAUSED
}

data class DownloadItem(
    val id: Long = 0L,
    val originalUrl: String,
    val title: String,
    val author: String = "",
    val platform: String,
    val quality: String,
    val thumbnail: String,
    val localFilePath: String? = null,
    val downloadUrl: String,
    val progress: Int = 0,
    val status: DownloadStatus = DownloadStatus.PENDING,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val duration: Long = 0L,
    val isAudioOnly: Boolean = false,
    val errorMessage: String? = null
)
