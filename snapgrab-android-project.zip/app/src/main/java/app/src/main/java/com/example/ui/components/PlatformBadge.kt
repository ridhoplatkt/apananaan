package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ColorFacebook
import com.example.ui.theme.ColorInstagram
import com.example.ui.theme.ColorPinterest
import com.example.ui.theme.ColorSpotify
import com.example.ui.theme.ColorTikTok
import com.example.ui.theme.ColorTwitter
import com.example.ui.theme.ColorYouTube

@Composable
fun PlatformBadge(
    platform: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, iconVector, label) = when (platform.lowercase()) {
        "youtube" -> Triple(ColorYouTube, Icons.Default.PlayArrow, "YouTube")
        "instagram" -> Triple(ColorInstagram, Icons.Default.CameraAlt, "Instagram")
        "tiktok" -> Triple(ColorTikTok, Icons.Default.Videocam, "TikTok")
        "twitter", "x" -> Triple(ColorTwitter, Icons.Default.Share, "X / Twitter")
        "facebook" -> Triple(ColorFacebook, Icons.Default.Share, "Facebook")
        "pinterest" -> Triple(ColorPinterest, Icons.Default.Share, "Pinterest")
        "spotify" -> Triple(ColorSpotify, Icons.Default.Audiotrack, "Spotify")
        else -> Triple(Color(0xFF8B5CF6), Icons.Default.Videocam, platform)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor.copy(alpha = 0.25f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = iconVector,
                contentDescription = label,
                tint = bgColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
